package com.javainuse.model;

public class Result {
	
	Boolean Sucessful;
	
	

}
