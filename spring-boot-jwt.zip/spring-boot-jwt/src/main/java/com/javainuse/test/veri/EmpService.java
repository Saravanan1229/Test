package com.javainuse.test.veri;

import java.util.List;



public interface EmpService {
	
    List<EmpModel> getAllEmpList();
	
	void saveEmp(EmpModel emp);
	
	
	public void save(EmpModel emp);




	
}
